import UIKit

class MyList {
    var randomNum = 0
    init(randomNum : Int) {
        self.randomNum = randomNum
    }
    func generateRandom() -> Int {
        let x = Int.random(in: 0...100)
        return x
    }
    
}
let a = MyList(randomNum: 0)
let b = MyList(randomNum: 0)
let c = MyList(randomNum: 0)
let d = MyList(randomNum: 0)
let e = MyList(randomNum: 0)
let f = MyList(randomNum: 0)
let g = MyList(randomNum: 0)
let h = MyList(randomNum: 0)
let i = MyList(randomNum: 0)
let j = MyList(randomNum: 0)
var array = [a.generateRandom(), b.generateRandom(), c.generateRandom(), d.generateRandom(), e.generateRandom(), f.generateRandom(), g.generateRandom(), h.generateRandom(), i.generateRandom(), j.generateRandom()]
print(array)
var newArray = Array(array.sorted().reversed())
print(newArray)
let dictionary = [newArray[0] : newArray[9]]
print(dictionary)
